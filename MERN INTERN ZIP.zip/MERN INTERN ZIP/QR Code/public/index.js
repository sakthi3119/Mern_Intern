let link = document.getElementById("link");
let btn = document.getElementById("btn");
let qrCode = document.getElementById("qrCode");

btn.addEventListener("click",(e)=>{
    e.preventDefault();
    if(link.value){
        generateQRCode();
    }else{
        alert("Please enter a link");
    }
})


// async function generateQRCode(){
//     let response = await fetch(`http://localhost:3000/qr?link=${link.value}`,{
//         method:"POST",
//         headers:{
//             "Content-Type":"application/json"
//         },
//         body:JSON.stringify({data:link.value})
//     })
//     response = await response.json();
//     console.log(response);
//     let img = document.createElement("img");
//     img.src=response
//     qrCode.innerHTML = "";
//     qrCode.append(img);
// }

async function generateQRCode(){
    let response = await fetch(`http://localhost:3000/qr?link=${link.value}`)
    response = await response.json();
    console.log(response);
    let img = document.createElement("img");
    img.src=response
    qrCode.innerHTML = "";
    qrCode.append(img);
}
