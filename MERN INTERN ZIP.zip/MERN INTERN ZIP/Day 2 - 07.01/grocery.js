let body = document.getElementById("data");
let ul = document.createElement("ul");


// let li1 = document.createElement("li");
// let li2 = document.createElement("li");
// let li3 = document.createElement("li");
// let li4 = document.createElement("li");
// let li5 = document.createElement("li");
// ul.append(li1, li2, li3, li4, li5);

// console.log(ul);

// let text1 = document.createTextNode("Apple");
// let text2 = document.createTextNode("Banana");
// let text3 = document.createTextNode("Cherry");
// let text4 = document.createTextNode("Dates");
// let text5 = document.createTextNode("Elderberry"); 

// li1.append(text1);
// li2.append(text2);
// li3.append(text3);
// li4.append(text4);
// li5.append(text5);

// console.log(ul);
// body.append(ul);
// ul.className = "divClass";

// ul.setAttribute("id", "tag");

// ul.style.color = "red";
// ul.style.cssText = `color:teal;`


// let li6 = document.createElement("li");
// let text6 = document.createTextNode("Fig");
// li6.append(text6);
// ul.append(li6);



let fruits = ["apple","orange","banana","grapes","mango","kiwi","papaya","watermelon","cherry","strawberry"];
fruits.map((i)=> {
    let li = document.createElement("li");
    let text = document.createTextNode(i);
    li.append(text);
    ul.prepend(li);
}); 
body.append(ul);
console.log(ul);

//console.log(body.children[1].remove());

//prepend - add element at the beginning
//append - add element at the end

let li = document.getElementById("one")
li.remove();

let date = new Date();
console.log(date.getDate());
console.log(date.getDay());
console.log(date.getHours());
console.log(date.getMinutes());
console.log(date.getSeconds());
console.log(date.getTime());
console.log(date.getMonth());
console.log(date.getFullYear());
console.log(date.getMilliseconds());    
console.log(date.toString());
console.log(date.toDateString());
console.log(date.toTimeString());
console.log(date.toLocaleString());
console.log(date.toLocaleDateString());
console.log(date.toLocaleTimeString());

