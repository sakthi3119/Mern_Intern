const counterButton = document.getElementById('counterButton');
const resetButton = document.getElementById('resetButton');
const counterDisplay = document.getElementById('counterDisplay');

// Initialize counter value from localStorage
let counter = parseInt(localStorage.getItem('counter'), 10) || 0;
updateCounterDisplay(counter);

// Sound effect
const clickSound = new Audio('click.mp3'); // Add a click sound file to your project

// Event listener for the counter button
counterButton.addEventListener('click', () => {
    counter++;
    updateCounterDisplay(counter);
    localStorage.setItem('counter', counter); // Save to localStorage

    // Play sound
    clickSound.currentTime = 0;
    clickSound.play();
});

// Event listener for the reset button
resetButton.addEventListener('click', () => {
    counter = 0;
    updateCounterDisplay(counter);
    localStorage.setItem('counter', counter); // Save to localStorage
});

// Function to update the counter display and change background color
function updateCounterDisplay(value) {
    counterDisplay.textContent = value;

    // Dynamic background color based on counter value
    const colors = ['#f4e04d', '#84fab0', '#a1c4fd', '#ff758c', '#ff7eb3'];
    const colorIndex = value % colors.length;
    counterDisplay.style.backgroundColor = colors[colorIndex];
}
