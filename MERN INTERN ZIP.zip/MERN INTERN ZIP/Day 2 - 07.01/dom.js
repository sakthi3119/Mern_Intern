// //getElementById
// //getElementByClassName
// //getElementByTagName
// //querySelector
// //querySelectorAll

// let h1 = document.getElementById("tag1");
// console.log(h1);

// //text manipulation
// //h1.innerHTML = "Hello World";
// //h1.innerText = "Hello World";
// //h1.textContent = "Hello World";

// //console.log(h1.innerHTML);

// //location.assign("https://www.google.com");


// console.log(screen);
// //history.back();


// let div = document.createElement("div");
// //div.innerText = "Created Div";  -not a best practice
// let textNode = document.createTextNode("Created Div");
// div.classList = "divClass";
// div.append(textNode);

// let body = document.getElementById("data");
// body.append(div);
// console.log(div);

// let list = document.getElementsByClassName("one");
// //let list = document.getElementsByClassName("one")[2];
// console.log(list); 

// let list1 = document.getElementsByTagName("li");
// //let list1 = document.getElementsByTagName("li")[0];
// console.log(list1);

// let list2 = document.querySelector("ul li"); //only first element
// console.log(list2);

// let list3 = document.querySelectorAll("ul li"); //all elements
// console.log(list3);

let button = document.getElementById("btn");
button.addEventListener("click",()=>{
    alert("you have clicked the button");
})

let parent = document.getElementsByClassName("div1")[0];
let child1 = document.getElementsByClassName("div2")[0];
let child2 = document.getElementsByClassName("div3")[0];

//function without names - anonymous function
// parent.addEventListener("click",()=>{
//     alert("you have clicked the parent");
// })

// child1.addEventListener("click",()=>{
//     alert("you have clicked the child1");
// })

// child2.addEventListener("click",(e)=>{
//     e.stopPropagation();
//     alert("you have clicked the child2");
// })

const event1 = (e)=>{
    alert("you have clicked the child2");
    remove();
}

child2.addEventListener("mouseleave",event1);
const remove = ()=>{
    child2.removeEventListener("mouseleave",event1);
}  //remove event listener

//target method - to get the element on which event is triggered
//target.tagname - to get the tag name of the element

//mouseup - when mouse is released
//mousedown - when mouse is pressed
//mouseover - when mouse is over the element
//mouseout - when mouse is out of the element
//mousemove - when mouse is moved
//mouseenter - when mouse enters the element
//mouseleave - when mouse leaves the element
//click - when mouse is clicked
//dblclick - when mouse is double clicked


const catchKeyboard = (e)=>{
    console.log(e);
}

window.addEventListener("keyup",catchKeyboard);


