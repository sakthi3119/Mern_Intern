import React, { useState } from 'react'
import { useDispatch } from "react-redux"
import { addPost } from "../slice/blogSlice"
import { useNavigate } from 'react-router-dom'
import './styles.css'

function CreatePost() {
    const [author, setAuthor] = useState("")
    const [data, setData] = useState("")
    const dispatch = useDispatch()
    const navigate = useNavigate()
    
    const handleCreatePost = () => {
        if (author && data) {
            dispatch(addPost({ author, data }))
            setAuthor("")
            setData("")
            navigate('/posts')
        }
    }

    return (
        <div className="create-post-container">
            <div className="create-post">
                <h2>Create New Blog Post</h2>
                <div className="form-group">
                    <label htmlFor="author">Author</label>
                    <input 
                        id="author" 
                        value={author} 
                        onChange={(e) => setAuthor(e.target.value)} 
                        type="text" 
                        placeholder='Enter author name'
                        className="input-field"
                    />
                </div>
                <div className="form-group">
                    <label htmlFor="data">Content</label>
                    <textarea 
                        id="data" 
                        value={data} 
                        onChange={(e) => setData(e.target.value)} 
                        placeholder='Write your blog post here...'
                        rows="6"
                        className="input-field"
                    />
                </div>
                <button className="submit-button" onClick={handleCreatePost}>Create Post</button>
            </div>
        </div>
    )
}

export default CreatePost