// const readLine = require('readline');
// const rl = readLine.createInterface({
//     input: process.stdin,
//     output: process.stdout
// });
// let variable=""
// rl.question('Enter your name: ', (name) => {
//     variable=name
// });
// console.log(variable);

// const os = require('os');
// console.log(os.homedir());
// console.log(os.tmpdir());
// //console.log(os.cpus());
// console.log(os.arch());
// console.log(os.platform());
// console.log(os.hostname());
// console.log(os.userInfo());
// console.log(os.freemem());
// console.log(os.totalmem());
// console.log(os.uptime());
// console.log(os.version());

const path = require('path');
// console.log(__dirname);
// console.log(__filename);
// console.log(path.basename("S:\II YEAR\MERN WINTER INTERN JAN 2025\Server\index.js")); 
// console.log(path.extname('sample.txt'));
//console.log(path.join("folder","index.js"));

console.log(path.parse("S:\II YEAR\MERN WINTER INTERN JAN 2025\Server\index.js"));
console.log(path.parse("c:index.js"));
