// const http = require("http")
// const fs = require("fs")
// const url = require("url")
// const server = http.createServer((req,res)=>{
//     // console.log(req.url)
//     // fs.readFile("index.html","utf-8",(err,data)=>{
//     //         res.writeHead(200,{'Content-Type':'text/html'})
//     //         res.end(data)
//     let {query} = url.parse(req.url,true)
//     console.log(query)
//     })
//     //res.end("hello")    

// server.listen(3000,()=>{console.log("server is running");
// })

const http = require("http")
const fs = require("fs")
const url = require("url")

// Add file watcher for sample.txt
fs.watch('sample.txt', (eventType, filename) => {
    const timestamp = new Date().toLocaleString()
    console.log(`File ${filename} was ${eventType} at: ${timestamp}`)
})

const server = http.createServer((req,res)=>{
    // Log timestamp for each request
    const timestamp = new Date().toLocaleString()
    console.log(`Request received at: ${timestamp}`)
    
    let {query} = url.parse(req.url,true)
    console.log(query)
    res.end("hi")
})

server.listen(3000,()=>{
    const startTimestamp = new Date().toLocaleString()
    console.log(`Server started at: ${startTimestamp}`)
    console.log("Server is running on port 3000")
})
