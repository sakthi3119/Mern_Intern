// const http = require("http")
// const fs = require("fs")
// const jsonData = require("./product.json")
// console.log(jsonData)


// const server = http.createServer((req,res)=>{
//     // res.writeHead(200,{'Content-Type':'application/json'})
//     // res.end(JSON.stringify(jsonData))
//     let path = req.url
//     if(path === "/home" || path === "/"){
//         fs.readFile("index.html","utf-8",(err,data)=>{
//             res.writeHead(200,{'Content-Type':'text/html'})
//             res.end(data)
//         })
//     }
//     else if(path === "/contact"){
//         res.end("contact")
//     }
//     else if(path === "/about"){
//         res.end("about")
//     }
//     else if(path === "/product"){
//         res.end("product")
//     }
//     else{
//         res.end("404 not found")
//     }
// })

// server.listen(3000,()=>{
//     console.log("http://127.0.0.1:3000")
// })

const http = require("http")
const fs = require("fs")
const path = require("path")
const data = fs.readFileSync(path.join(__dirname,"templates","template.html"),"utf-8")
const productData = fs.readFileSync(path.join(__dirname,"templates","product.html"),"utf-8")
const jsonData = JSON.parse(fs.readFileSync("product.json","utf-8"))
const url = require("url")
// console.log(jsonData)
let productHtmlArray = jsonData.map((prod)=>{
    let output = productData.replace("{{%IMAGE%}}",prod.productImage)
    output = output.replace("{{%NAME%}}",prod.name)
    output = output.replace("{{%MODNAME%}}",prod.modeName)
    output = output.replace("{{%MODNUMBER%}}",prod.modelNumber)
    output = output.replace("{{%SIZE%}}",prod.size)
    output = output.replace("{{%CAMERA%}}",prod.camera)
    output = output.replace("{{%PRICE%}}",prod.price)
    output = output.replace("{{%COLOR%}}",prod.color)
    output = output.replace("{{%ID%}}",prod.id)
    return output
})
productHtmlArray = productHtmlArray.join("")
console.log(productHtmlArray)

function renderProduct(prod){
    let output = productData.replace("{{%IMAGE%}}",prod.productImage)
    output = output.replace("{{%NAME%}}",prod.name)
    output = output.replace("{{%MODNAME%}}",prod.modeName)
    output = output.replace("{{%MODNUMBER%}}",prod.modelNumber)
    output = output.replace("{{%SIZE%}}",prod.size)
    output = output.replace("{{%CAMERA%}}",prod.camera)
    output = output.replace("{{%PRICE%}}",prod.price)
    output = output.replace("{{%COLOR%}}",prod.color)
    output = output.replace("{{%ID%}}",prod.id)
    return output
}
const server = http.createServer((req,res)=>{
    let path = req.url
    path = path.toLowerCase()
    let {query,pathname} = url.parse(req.url,true)
    pathname = pathname.toLowerCase()
    console.log(query.id)
    if(path === "/home" || path === "/"){
        res.writeHead(200, {'Content-Type': 'text/html'})
        res.end(data.replace("{{%CONTENT%}}","You are at Home"))
    }
    else if(path === "/contact"){
        res.writeHead(200, {'Content-Type': 'text/html'})
        res.end(data.replace("{{%CONTENT%}}","You are at Contact"))
    }
    else if(path === "/about"){
        res.writeHead(200, {'Content-Type': 'text/html'})
        res.end(data.replace("{{%CONTENT%}}","You are at About"))
    }
    else if(pathname === "/products"){
        res.writeHead(200, {'Content-Type': 'text/html'})
        let id = query.id*1
        if(query.id){
            let find = jsonData.find((prod)=>prod.id === id)
            res.end(data.replace("{{%CONTENT%}}",renderProduct(find)))
        }
        else{
            res.end(data.replace("{{%CONTENT%}}",productHtmlArray))
        }
    }
    else{
        res.writeHead(404, {'Content-Type': 'text/plain'})
        res.end("404 not found")
    }
})
server.listen(3000,()=>{
    console.log("http://127.0.0.1:3000")
})