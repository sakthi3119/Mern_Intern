const fs = require('fs');
//fs.writeFile("sample.txt","Change of data",(err)=>{})
//fs.appendFile("sample.txt","\nAppended data",(err)=>{})
// fs.readFile("sample.txt","utf-8",(err,data)=>{
//     console.log(data);
// })

// fs.unlink("sample.txt",(err)=>{
//     console.log("File deleted");
// })


    // fs.readFile("sample.t","utf-8",(err,data)=>{
    //     if(err){
    //        throw err;
    //     }
    //     else{
    //         console.log(data);
    //     }
    // })

    // process.on("uncaughtException",(err)=>{
    // console.log(err.message);
    // })

// fs.mkdir("folder",(err)=>{
//     console.log("Folder created");
// })

// fs.rmdir("folder",(err)=>{
//     if(err){
//         console.log(err.message);
//     }
//     else{
//         console.log("Folder deleted");
//     }
// })

// fs.readFile("sample.txt","utf-8",(err,data)=>{
//     if(err){
//         console.log(err.message);
//     }
//     else{
//         console.log(data);
//     }
// })
// console.log("Hello");

// const fileData = fs.readFileSync("sample.txt","utf-8");
// console.log(fileData);
// console.log("Hello");

// fs.writeFile("firstfile.txt","firstfile",()=>{
//     fs.appendFile("firstfile.txt","First Appended",()=>{
//         fs.readFile("firstfile.txt","utf-8",(err,data)=>{
//             console.log(data);
//         })
//     })
// })

fs.writeFileSync("firstfile.txt", "firstfile");
fs.appendFileSync("firstfile.txt", "First Appended");
const data = fs.readFileSync("firstfile.txt", "utf-8");
console.log(data);


