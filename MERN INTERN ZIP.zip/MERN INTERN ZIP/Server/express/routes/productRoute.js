const express = require('express');
const ProductRoutes = express.Router();
const {getProducts,getProductById,createProduct,updateProduct,deleteProduct,validate,idvaluegetter} = require('../routehandlers/productFunctions');

ProductRoutes.param("id",idvaluegetter);



ProductRoutes.route("/")
.get(getProducts)
.post(validate,createProduct)

ProductRoutes.route("/:id")
.get(getProductById)
.delete(deleteProduct)
.patch(updateProduct)
.put(updateProduct);

module.exports = ProductRoutes;