// const http = require('http');

// const server = http.createServer()

// server.on('request', (req, res) => {
//     console.log('Request received');
//     res.end('Hello World');
// });

// server.listen(3000);

// const events = require('events');
// const CustomEvent = new events.EventEmitter();

// CustomEvent.on("cs",()=>{
//     console.log("Event has been triggered");
// })

// CustomEvent.emit("cs");


// const express = require('express')

// const app = express();

// app.get('/', (req, res) => {
//     // console.log("Server called");
//     // res.send('Hello World');
//     // res.json({ok:true})
//     res.status(200).sendFile(__dirname + '/index.html');
//     res.setHeader('Content-Type', 'text/html');
//     res.set({'Name':'SECE','Location':'CBE'});
// });

// app.listen(3000,()=>{
//     console.log("Server is running")
// });

const express = require('express');
const app = express();
app.use(express.json());
const morgan = require('morgan');
app.use(morgan('dev'));
const dotenv = require('dotenv');
dotenv.config({path:"./config.env"});
const ProductRoutes = require('./routes/productRoute');

app.use("/api/v1/products",ProductRoutes);
module.exports=app

// app.use(mid)
// function mid(req,res,next){
//     console.log("Middleware called");
//     next();
// }
// app.get("/api/v1/products",getProducts);
// app.get("/api/v1/products/:id",getProductById); 
// // app.get("/*",(req,res)=>{
// //     res.json({
// //         status:"error",
// //         message:"Page not found"
// //     })
// // })
// app.post("/api/v1/products", createProduct);
// app.delete("/api/v1/products/:id", deleteProduct);
// app.patch("/api/v1/products/:id", updateProduct);
// app.put("/api/v1/products/:id", updateProduct);


//route combine - route chaining
// ProductRoutes.route("/")
// .get(getProducts)
// .post(createProduct)

// ProductRoutes.route("/:id")
// .get(getProductById)
// .delete(deleteProduct)
// .patch(updateProduct)
// .put(updateProduct);


