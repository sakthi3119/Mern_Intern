import React from "react";
import {Header} from "./Header.jsx";
import Content from "./Content.jsx";
import Footer from "./Footer.jsx";
import Counter from "./Counter/Counter.jsx";
export const App = () => {
  return (
    <div>
      {/* <Header />
      <Content/>
      <Footer /> */}
      <Counter/>
    </div>
  );
};

