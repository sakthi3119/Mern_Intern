localStorage.setItem("getback",2500)
console.log(localStorage.getItem("getback"))
localStorage.removeItem("getback")
console.log(localStorage.getItem("getback"))

// let count = 0;
// count++
// localStorage.setItem("reload",count)
// console.log(localStorage.getItem("reload"))


//Assignment-1 - DAY 3
let count = 0;
count = localStorage.getItem("reload");
count++;
localStorage.setItem("reload", count);
console.log(localStorage.getItem("reload"));
//localStorage.removeItem("reload")

