import React from 'react'

function Newbook() {
  return (
    <div>Newbook</div>
  )
}

export default Newbook