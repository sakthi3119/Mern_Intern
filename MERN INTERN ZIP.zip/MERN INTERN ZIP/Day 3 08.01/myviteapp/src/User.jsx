import React from 'react'
import { useParams } from 'react-router-dom'
import { useNavigate } from 'react-router-dom';
function User() {
  const routeParam=useParams()
  console.log(routeParam);

  const navigate=useNavigate()
  function handleClick()
  {
    navigate("/home")
  }
  return (

    <div>
      User:{routeParam.id1}
      <button onClick={handleClick}>Home</button>
    </div>
    
  )
}

export default User