import React from 'react'
import { useEffect,useState } from 'react'
import useFetcher from './useFetcher'

function ApiCall() {
    const [data,setData]=useState([])
    let hookResponse = useFetcher("https://jsonplaceholder.typicode.com/posts")
    console.log(hookResponse)
   
  return (
    <div>
        {data.map((i)=><li>{i.body}</li>)}
    </div>
  )
}

export {ApiCall}