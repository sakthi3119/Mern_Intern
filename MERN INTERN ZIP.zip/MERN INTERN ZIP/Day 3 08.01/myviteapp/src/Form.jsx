import React,{useState} from 'react'
function Form () {
    const [data,setData]=useState({email:"example@gmail.com",pass:""})
    function handleChange(e)
    {
        setData({...data,email:e.target.value})
    }
    console.log(data);
    
  return (
    <>
    <div className='min-h-screen bg-stone-600 shadow-amber-300 justify-items-center py-10'>
        <form action="" className=''> 
            <div className='p-10 rounded-lg bg-red-700 py-4 px-4 shadow-amber-300'>
            <div>
            <label htmlFor ="" className='text-fuchsia-50 font-mono '>Email</label>
            <input value={data.email} onChange={(e)=>handleChange(e)} placeholder="Enter your Email" type="text" className="w-full px-1 py-1 text-zinc-600 bg-amber-200 border rounded-md placeholder-slate-500 "/>
            </div>       
            <div>     
            <label htmlFor="" className='font-mono text-fuchsia-50'>Password</label>
            <input onChange={(e)=>setData({...data,pass:e.target.value})} value={data.pass} placeholder="Enter your Password" type="password" className="w-full px-1 py-1 text-zinc-600 bg-amber-200 border rounded-md placeholder-slate-500"/>
            </div>
            <br></br>
            <div className='px-20'>
            <div className=''>
            <button type="submit" className="w-full p-3 rounded-lg bg-black text-gray-50 font-serif py-1">Login</button>
            </div>
            </div>
            </div>
        </form>
    </div>
    </>
  )
}

export default Form