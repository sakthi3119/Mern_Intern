// 1. functional components
// const Header=()=>{
//     // let data=["Apple","Banana","Fig"]
//     return(
//         <div>
//             {/* {data.map((i,k) => {
//                 return(
//                     <li key={k}>{i}</li>
//                 )
//             })} */}


//         </div>
//     )
// }
// export {Header};

// import React from 'react'

// function Header() {
//   return (
//     <div>Header</div>
//   )
// }

// function Header1() {
//     return (
//       <div>Header</div>
//     )
//   }
// export {Header}

//conditional rendering 
const Header = () => {
    // if(true)
    // {
    //     return(
    //         <h1>It's for client</h1>
    //     )
    // }
    // else{

    // }
    let data=[]
    return
    (
        <div>
            
                {/* {!data.length>0 &&  
                    <h1>Yeah!</h1>
} */}

        { data.length>0?<h1>Yes there is Data</h1>:<h1>No More Data</h1>}        
        </div>
                )
            }
        
export {Header}
