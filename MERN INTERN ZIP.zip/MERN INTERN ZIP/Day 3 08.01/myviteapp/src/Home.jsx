import React from 'react'
import Form from './Form'
function Home() {
  return (
      <div>
      {/* <h1 className='bg-teal-400 w-20 h-20 font-serif text-neutral-50 underline decoration-orange-300 font-bold rounded-lg '>Hello h1</h1> */}
      
      {/* <div className='h-screen flex bg-black text-white m-10 flex-col'>
      {/* <h1 className='bg-teal-400 w-12 h-10 font-serif text-xl font-extrabold text-red-500 underline decoration-slate-400 
      0 rounded-lg ring-1 border-2 border-red-500
      shadow-xl shadow-orange-500 opacity-50 rotate-36 hover:rotate-90 transition-all delay-150 duration-1000 m-10'>Hell</h1>*/}
      {/* <div className='bg-red-500'>Container1</div>
      <div className='bg-violet-500'>Container2</div>
      <div className='bg-blue-500'>Container3</div>
      <div className='bg-yellow-500'>Container4</div>
      <div className='bg-pink-400'>Container5</div> */}
      {/* </div> */}

      <Form/>

      </div> 
  )
}

export default Home