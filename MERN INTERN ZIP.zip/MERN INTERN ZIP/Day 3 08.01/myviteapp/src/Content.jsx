const Content=({pData})=>
    {
    let cData = "This Data is from the Child"
    function handleClick()
    {
        pData(cData)
    }
    return(
        <div>
            <button onClick={()=>handleClick("You clicked the Button")}>Content</button>
        </div>
    )
}

export {Content}