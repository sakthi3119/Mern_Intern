// import {Header} from "./Header"
// import {Footer} from "./Footer"
// import {Content} from "./Content"
// import Component1 from "./Components"
// import {Component2,Component3,Component4,Component5} from "./Components"
// import {ApiCall} from "./ApiCall"
// import Todo from "./Todo"
import {BrowserRouter,Routes,Route,Link} from 'react-router-dom'
import Home from './Home'
import About from './About'
import Contact from './Contact'
import Newbook from './Newbook'
import Oldbook from './Oldbook'
import User from './User'


function App() 
{
  
  // function getData(data)
  // {
  //   console.log(data)
  // }
  return (
    <>
    <BrowserRouter> 
     {/* <ul>
      <li><Link to="/home">Home</Link></li>
      <li><Link to="/contact">Contact</Link></li>
      <li><Link to="/about">About</Link></li>
    </ul>  */}
       <Routes>
        <Route path='/home' element={<Home/>}/>
        <Route path='/about' element={<About/>}/>
        <Route path='/contact' element={<Contact/>}/>
        <Route path='/books'>
        <Route path='oldbooks' element={<Oldbook/>}/>
        <Route path='newbooks' element={<Newbook/>}/>
        </Route>
        <Route path='/user/:id1' element={<User/>}/>
      </Routes>
      </BrowserRouter>
      
    </>
    )
}
export default App


