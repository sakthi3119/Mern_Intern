const Component1 = () => {
  return (
    <div>Component1</div>
  )
}

export const Component2 = () => {
    return (
      <div>Component2</div>
    )
}

const Component3 = () => {
    return (
      <div>Component3</div>
    )
}

const Component4 = () => {
    return (
      <div>Component4</div>
    )
}

const Component5 = () => {
    return (
      <div>Component5</div>
    )
}
export default Component1;
export {Component3,Component4,Component5}
