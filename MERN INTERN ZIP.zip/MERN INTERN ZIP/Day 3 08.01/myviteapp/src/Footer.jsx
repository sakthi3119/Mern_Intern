import React from 'react'
import { useState , useRef,useContext} from 'react';
import MyContext from './ContextAPI';
const Footer = () => {
    const refer=useRef()
    //const [data,setData]=useState(0);
  function handleClick()
  {
    refer.current.focus()
  }
  let dataFromGlobal=useContext(MyContext)
  return (
 
      <div>
        {dataFromGlobal}
       <input ref={refer} type = "text"/>
        <button onClick={handleClick}>Focus</button>
      </div>
      
    
  )
}

export {Footer}